
REGION=$1
ENV=$2
BUILD_NUMBER=$3

if [ $# -ne 3 ]; then
    echo "Error: Script expects exactly three arguments: region, environment and build number"
    exit 1
fi

# aws lambdas
lambda[0]=AWS
lambda[1]=lambda

# Flag variable to track failure
hasFailure=false

for i in "${!lambda[@]}"
do
    ./${lambda[i]}/docker_push_image.sh ${lambda[i]} ${BUILD_NUMBER}

    if [ $i -eq 0 ] && [ $? -ne 0 ]; then
        echo ${lambda[i]} "failed"
        hasFailure=true
        break 2  # Exits the outer loop
    fi
done

if [ "$hasFailure" = true ]; then
    echo "At least one iteration failed."
    exit 1
fi

read -n 1 -s -r -p "Press any key to exit..."