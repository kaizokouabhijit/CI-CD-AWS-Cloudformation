

def lambda_handler(event, context):
    print("Hello World")
    print(context)



lambda_handler(event=None, context="testing")